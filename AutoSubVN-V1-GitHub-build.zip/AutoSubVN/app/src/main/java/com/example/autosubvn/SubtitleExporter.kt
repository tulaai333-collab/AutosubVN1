package com.example.autosubvn

import android.content.Context
import android.graphics.Color
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

@androidx.media3.common.util.UnstableApi
class TimedTextOverlay(private val items: List<SubtitleSegment>) : TextOverlay() {
    private val settings = StaticOverlaySettings.Builder()
        .setBackgroundFrameAnchor(0f, -0.82f)
        .setOverlayFrameAnchor(0f, 0f)
        .setScale(0.75f, 0.75f)
        .build()

    override fun getText(presentationTimeUs: Long): SpannableString {
        val t = presentationTimeUs / 1000
        val text = items.firstOrNull { t in it.startMs..it.endMs }?.translation.orEmpty()
        val s = SpannableString(text)
        if (text.isNotEmpty()) s.setSpan(ForegroundColorSpan(Color.WHITE), 0, text.length, 0)
        return s
    }

    override fun getOverlaySettings(presentationTimeUs: Long) = settings
}

@androidx.media3.common.util.UnstableApi
object SubtitleExporter {
    fun export(context: Context, input: android.net.Uri, items: List<SubtitleSegment>, out: File, onDone: (Result<File>) -> Unit) {
        val overlay = TimedTextOverlay(items)
        val effect: Effect = OverlayEffect(listOf(overlay))
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(input))
            .setEffects(Effects(emptyList(), listOf(effect)))
            .build()
        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, result: ExportResult) {
                    onDone(Result.success(out))
                }
                override fun onError(composition: androidx.media3.transformer.Composition, result: ExportResult, exportException: ExportException) {
                    onDone(Result.failure(exportException))
                }
            }).build()
        transformer.start(edited, out.absolutePath)
    }
}
