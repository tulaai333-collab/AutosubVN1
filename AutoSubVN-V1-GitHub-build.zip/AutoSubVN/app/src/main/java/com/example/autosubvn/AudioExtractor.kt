package com.example.autosubvn

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File

object AudioExtractor {
    fun extractAudio(context: Context, uri: Uri, outFile: File) {
        val extractor = MediaExtractor()
        context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
            extractor.setDataSource(pfd.fileDescriptor)
        } ?: error("Không mở được video")

        var audioTrack = -1
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) { audioTrack = i; break }
        }
        if (audioTrack < 0) { extractor.release(); error("Video không có track âm thanh") }

        extractor.selectTrack(audioTrack)
        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val dst = muxer.addTrack(extractor.getTrackFormat(audioTrack))
        muxer.start()
        val buffer = java.nio.ByteBuffer.allocate(1024 * 1024)
        val info = android.media.MediaCodec.BufferInfo()
        try {
            while (true) {
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                info.offset = 0
                info.size = size
                info.presentationTimeUs = extractor.sampleTime
                info.flags = extractor.sampleFlags
                muxer.writeSampleData(dst, buffer, info)
                extractor.advance()
                buffer.clear()
            }
        } finally {
            muxer.stop(); muxer.release(); extractor.release()
        }
    }
}
