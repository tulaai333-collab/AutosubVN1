package com.example.autosubvn

import java.io.File
import java.util.Locale

object SrtWriter {
    fun write(file: File, items: List<SubtitleSegment>) {
        file.bufferedWriter(Charsets.UTF_8).use { w ->
            items.forEachIndexed { i, s ->
                w.append((i + 1).toString()).append('\n')
                w.append(time(s.startMs)).append(" --> ").append(time(s.endMs)).append('\n')
                w.append(if (s.translation.isBlank()) s.source else s.translation).append("\n\n")
            }
        }
    }
    private fun time(ms: Long): String {
        val h = ms / 3_600_000; val m = (ms % 3_600_000) / 60_000
        val s = (ms % 60_000) / 1000; val x = ms % 1000
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, x)
    }
}
