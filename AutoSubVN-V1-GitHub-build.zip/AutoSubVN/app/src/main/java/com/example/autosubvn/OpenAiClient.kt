package com.example.autosubvn

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class OpenAiClient(private val apiKey: String) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.MINUTES)
        .writeTimeout(10, TimeUnit.MINUTES)
        .build()

    fun transcribe(audio: File, language: String?): List<SubtitleSegment> {
        val builder = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", audio.name, audio.asRequestBody("video/mp4".toMediaType()))
            .addFormDataPart("model", "whisper-1")
            .addFormDataPart("response_format", "verbose_json")
            .addFormDataPart("timestamp_granularities[]", "segment")
        if (!language.isNullOrBlank() && language.lowercase() != "auto") builder.addFormDataPart("language", language)

        val req = Request.Builder()
            .url("https://api.openai.com/v1/audio/transcriptions")
            .header("Authorization", "Bearer $apiKey")
            .post(builder.build()).build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("Whisper lỗi ${r.code}: $body")
            val obj = JSONObject(body)
            val arr = obj.optJSONArray("segments") ?: error("API không trả về timestamp segments")
            return buildList {
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i)
                    add(SubtitleSegment(
                        (s.optDouble("start") * 1000).toLong(),
                        (s.optDouble("end") * 1000).toLong(),
                        s.optString("text").trim()
                    ))
                }
            }
        }
    }

    fun translateBatch(items: List<SubtitleSegment>, target: String = "Vietnamese") {
        if (items.isEmpty()) return
        val payload = JSONArray()
        items.forEachIndexed { index, s ->
            payload.put(JSONObject().put("id", index + 1).put("text", s.source))
        }
        val prompt = "Translate each subtitle item into natural Vietnamese. Keep names, slang and meaning. Do not explain. Return ONLY a JSON array of objects in the same order, each with keys id and translation. Input: $payload"
        val json = JSONObject()
            .put("model", "gpt-5.6-luna")
            .put("input", prompt)
        val req = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("Dịch lỗi ${r.code}: $body")
            val root = JSONObject(body)
            val outputText = root.optString("output_text")
            if (outputText.isBlank()) error("API không trả về output_text")
            val clean = outputText.substringAfter("[").let { "[" + it.substringBeforeLast("]") + "]" }
            val arr = JSONArray(clean)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getInt("id") - 1
                if (id in items.indices) items[id].translation = o.optString("translation").trim()
            }
        }
    }
}
