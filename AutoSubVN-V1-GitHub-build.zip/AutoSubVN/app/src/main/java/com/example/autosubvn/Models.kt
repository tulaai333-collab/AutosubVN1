package com.example.autosubvn

data class SubtitleSegment(
    val startMs: Long,
    val endMs: Long,
    val source: String,
    var translation: String = ""
)
