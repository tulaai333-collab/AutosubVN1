package com.example.autosubvn

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlin.coroutines.resume
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AutoSubApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutoSubApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var apiKey by remember { mutableStateOf("") }
    var language by remember { mutableStateOf("auto") }
    var status by remember { mutableStateOf("Sẵn sàng") }
    var running by remember { mutableStateOf(false) }
    var resultFile by remember { mutableStateOf<File?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            try { context.contentResolver.takePersistableUriPermission(it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            videoUri = it
        }
    }

    val player = remember(videoUri) {
        videoUri?.let {
            ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(it)); prepare() }
        }
    }
    DisposableEffect(player) { onDispose { player?.release() } }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("AutoSub VN • V1") }) }) { pad ->
            Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Dịch phụ đề video tự động", style = MaterialTheme.typography.titleLarge)
                Text("V1 dùng Whisper để nhận diện lời thoại, AI để dịch sang tiếng Việt, rồi burn phụ đề vào video.", style = MaterialTheme.typography.bodyMedium)

                OutlinedButton(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (videoUri == null) "🎬 Chọn video" else "Đổi video")
                }

                if (player != null) {
                    AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxWidth().height(210.dp))
                }

                OutlinedTextField(
                    value = apiKey, onValueChange = { apiKey = it },
                    label = { Text("OpenAI API key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                )
                Text("API key chỉ dùng trong phiên này, không được lưu vào máy.", style = MaterialTheme.typography.bodySmall)

                OutlinedTextField(value = language, onValueChange = { language = it },
                    label = { Text("Ngôn ngữ nguồn (auto/en/ja/ko/zh...)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth())

                Button(
                    enabled = !running && videoUri != null && apiKey.startsWith("sk-"),
                    onClick = {
                        val uri = videoUri ?: return@Button
                        running = true; resultFile = null; status = "Đang tách âm thanh..."
                        scope.launch(Dispatchers.IO) {
                            try {
                                val dir = File(context.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES), "AutoSub")
                                dir.mkdirs()
                                val audio = File(dir, "audio_${System.currentTimeMillis()}.mp4")
                                val client = OpenAiClient(apiKey.trim())
                                AudioExtractor.extractAudio(context, uri, audio)
                                status = "Đang nhận diện giọng nói..."
                                val segments = client.transcribe(audio, language.trim())
                                if (segments.isEmpty()) error("Không nhận diện được lời thoại")
                                status = "Đang dịch ${segments.size} đoạn..."
                                segments.chunked(8).forEach { client.translateBatch(it) }
                                val srt = File(dir, "subtitle_${System.currentTimeMillis()}.srt")
                                SrtWriter.write(srt, segments)
                                status = "Đang ghép phụ đề vào video..."
                                val out = File(dir, "AutoSub_${System.currentTimeMillis()}.mp4")
                                kotlinx.coroutines.suspendCancellableCoroutine<Result<File>> { cont ->
                                    SubtitleExporter.export(context, uri, segments, out) { r -> if (cont.isActive) cont.resume(r) {} }
                                }.getOrThrow()
                                audio.delete()
                                resultFile = out
                                status = "Xong! Video + SRT đã được tạo."
                            } catch (e: Exception) {
                                status = "Lỗi: ${e.message ?: e.javaClass.simpleName}"
                            } finally { running = false }
                        }
                    }, modifier = Modifier.fillMaxWidth())
                { Text(if (running) "Đang xử lý..." else "🚀 Dịch & xuất video") }

                if (running) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text(status, style = MaterialTheme.typography.bodyMedium)
                resultFile?.let { Text("Video: ${it.absolutePath}", style = MaterialTheme.typography.bodySmall) }
                Text("Vị trí file: Android/data/com.example.autosubvn/files/Movies/AutoSub", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
