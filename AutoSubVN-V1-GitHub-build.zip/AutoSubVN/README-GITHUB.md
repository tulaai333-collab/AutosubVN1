# AutoSub VN V1 — GitHub Build

Bản này được chuẩn bị để build APK bằng GitHub Actions, không cần PC.

## Cấu trúc repository

Upload **nội dung bên trong thư mục AutoSubVN** vào root của GitHub repository. Sau khi upload, các file/thư mục sau phải nằm ở cấp cao nhất:

- `app/`
- `gradle/`
- `build.gradle.kts`
- `settings.gradle.kts`
- `.github/workflows/build-apk.yml`

## Build APK

1. Tạo repository GitHub mới.
2. Upload toàn bộ source theo cấu trúc trên.
3. Mở tab **Actions**.
4. Chọn **Build AutoSub VN APK**.
5. Bấm **Run workflow**.
6. Khi job có dấu xanh, mở lần chạy đó.
7. Ở cuối trang, tải artifact **AutoSubVN-debug-apk**.
8. Giải nén artifact và cài `app-debug.apk` trên Android.

Workflow dùng JDK 17 và Gradle 8.10.2. APK là bản debug để thử nghiệm.

## Chức năng V1

- Chọn video từ Android
- Preview video
- Tách audio bằng Android MediaExtractor/MediaMuxer
- Gửi audio tới OpenAI transcription API
- Dịch segment sang tiếng Việt
- Xuất SRT
- Burn phụ đề vào MP4 bằng Media3 Transformer

API key không được đưa vào source hoặc GitHub Actions. Người dùng nhập key trong app.
