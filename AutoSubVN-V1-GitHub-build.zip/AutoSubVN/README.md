# AutoSub VN V1 — Android

Ứng dụng Android cá nhân để tự động nhận diện lời thoại, dịch sang tiếng Việt, xuất SRT và burn phụ đề vào video.

## V1 làm được
- Chọn video từ bộ nhớ Android.
- Tách audio track bằng MediaExtractor/MediaMuxer, không cần FFmpeg.
- Gửi audio lên OpenAI Audio Transcriptions để nhận diện lời thoại theo segment.
- Dịch các segment sang tiếng Việt bằng Responses API.
- Xuất file `.srt`.
- Burn phụ đề vào MP4 bằng AndroidX Media3 Transformer + TextOverlay.
- Preview video trước khi xử lý.

## Yêu cầu
- Android 8.0+ (API 26+).
- Internet.
- OpenAI API key của người dùng.
- Video có audio track mà thiết bị có thể đọc/đóng gói bằng MediaExtractor/MediaMuxer.

## Build APK ngay trên điện thoại
Cách dễ nhất là mở project bằng AndroidIDE (hoặc IDE Android có Gradle 8.10.2 + JDK 17), sync rồi chạy:

```text
gradle :app:assembleDebug
```

APK tạo ra ở:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Build bằng GitHub Actions — không cần PC
Project đã kèm `.github/workflows/build-apk.yml`.
1. Tạo một repository GitHub mới.
2. Upload toàn bộ thư mục project vào repository.
3. Mở tab **Actions** → workflow **Build AutoSub VN APK** → **Run workflow**.
4. Chờ build xong → mở job → phần **Artifacts** → tải `AutoSubVN-debug-apk`.
5. Giải nén và cài `app-debug.apk` trên Android.

## Lưu ý API key
V1 chỉ giữ API key trong bộ nhớ của phiên chạy; không ghi key vào SharedPreferences hay file cấu hình.

Chi phí API phụ thuộc thời lượng video và model. Không nhúng API key cố định vào APK.
